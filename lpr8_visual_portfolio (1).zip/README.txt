ВИЗУАЛЬНОЕ ПОРТФОЛИО — ЛПР № 8

Откройте index.html в браузере. Вёрстка содержит визуальные карточки проектов, CSS-макеты интерфейсов, адаптивную сетку, SEO и Open Graph.

Для GitHub Pages:
1) В index.html замените ВАШ-ЛОГИН на ваш GitHub username в og:url.
2) Создайте публичный репозиторий portfolio и загрузите index.html вместе с папкой assets.
3) Settings → Pages → Deploy from a branch → main → /(root) → Save.
4) Ссылка будет https://ВАШ-ЛОГИН.github.io/portfolio/
Контакт hello@example.com — демонстрационный, замените его на свой.
